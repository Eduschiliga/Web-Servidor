<?php

        session_start();

        require ("../views/header.view.php");
        require ("../views/processos.view.php");
        require ("../views/footer.view.php");

?>