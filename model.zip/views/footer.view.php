<footer>
    <p>&copy; Copyright - PAS System LTDA - ME - 2024</p>
    <p>Versão: 0.0.1 - Atualizado em 16/04/2024</p>
</footer>